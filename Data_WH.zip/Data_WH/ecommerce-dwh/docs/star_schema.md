# Star Schema

## Dimensions

- dim_customer
- dim_product
- dim_seller
- dim_date

## Facts

- fact_sales
- fact_payments
- fact_delivery
- fact_reviews

## Relationship Model

fact_sales links to:
- customer
- product
- seller
- date

fact_payments links to:
- customer
- date

fact_delivery links to:
- customer
- seller
- date

fact_reviews links to:
- customer
- date