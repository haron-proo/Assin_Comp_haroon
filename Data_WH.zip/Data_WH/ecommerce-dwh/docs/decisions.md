# Design Decisions

## Why Kimball?

Fast analytical querying and simple dimensional design.

## Why Fact Sales Grain = Order Item?

Each order item represents a real business sale event.

## Why SCD Type 2?

To preserve historical changes in dimensions.

## Why Materialized Views?

To improve reporting performance.

## Why PostgreSQL?

Strong analytical capability and indexing support.