# E-Commerce Data Warehouse Architecture

## Architecture Pattern

Kimball Dimensional Modeling

## Data Flow

Source System (SQLite)
        ↓
CSV Extraction Layer
        ↓
Raw Layer (PostgreSQL)
        ↓
Staging Layer
        ↓
Data Warehouse Layer
        ↓
Analytics Layer
        ↓
Materialized Views

## Layers

### Raw Layer
Stores source data as-is.

### Staging Layer
Performs data cleaning and standardization.

### Data Warehouse Layer
Stores dimensional and fact models.

### Analytics Layer
Stores business analytical queries and materialized views.

## Technology Stack

- SQLite (Source)
- Python (ETL)
- PostgreSQL (Warehouse)