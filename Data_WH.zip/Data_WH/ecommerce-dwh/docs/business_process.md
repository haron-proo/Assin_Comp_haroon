# Business Processes

## Sales Process
Tracks product sales at order-item level.

## Payment Process
Tracks payment transactions.

## Delivery Process
Tracks shipping and delivery performance.

## Review Process
Tracks customer satisfaction and review behavior.