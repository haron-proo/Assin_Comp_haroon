# Grain Definitions

## fact_sales
One row per order item.

## fact_payments
One row per payment transaction.

## fact_delivery
One row per delivered order.

## fact_reviews
One row per review event.