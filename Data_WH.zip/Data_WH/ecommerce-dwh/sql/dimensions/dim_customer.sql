INSERT INTO dwh.dim_customer (
    customer_id,
    customer_unique_id,
    customer_zip_code_prefix,
    customer_city,
    customer_state,
    effective_date,
    expiry_date,
    is_current
)
SELECT
    customer_id,
    customer_unique_id,
    customer_zip_code_prefix,
    customer_city,
    customer_state,
    CURRENT_DATE,
    NULL,
    TRUE
FROM staging.stg_customers;