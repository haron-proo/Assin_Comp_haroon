INSERT INTO dwh.dim_date (
    date_key,
    full_date,
    year,
    quarter,
    month,
    day,
    week,
    day_name,
    month_name
)
SELECT
    TO_CHAR(d::date, 'YYYYMMDD')::INTEGER AS date_key,
    d::date,
    EXTRACT(YEAR FROM d),
    EXTRACT(QUARTER FROM d),
    EXTRACT(MONTH FROM d),
    EXTRACT(DAY FROM d),
    EXTRACT(WEEK FROM d),
    TO_CHAR(d, 'Day'),
    TO_CHAR(d, 'Month')
FROM generate_series(
    '2016-01-01'::date,
    '2020-12-31'::date,
    interval '1 day'
) AS d;