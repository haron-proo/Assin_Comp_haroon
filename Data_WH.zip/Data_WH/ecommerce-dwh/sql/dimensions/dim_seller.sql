INSERT INTO dwh.dim_seller (
    seller_id,
    seller_zip_code_prefix,
    seller_city,
    seller_state,
    effective_date,
    expiry_date,
    is_current
)
SELECT
    seller_id,
    seller_zip_code_prefix,
    seller_city,
    seller_state,
    CURRENT_DATE,
    NULL,
    TRUE
FROM staging.stg_sellers;