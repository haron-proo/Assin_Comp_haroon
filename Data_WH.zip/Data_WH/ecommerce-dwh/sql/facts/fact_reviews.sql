INSERT INTO dwh.fact_reviews (
    review_id,
    order_id,
    customer_sk,
    date_key,
    review_score,
    review_comment_title,
    review_comment_message
)
SELECT
    r.review_id,
    r.order_id,

    dc.customer_sk,

    TO_CHAR(
        r.review_creation_date,
        'YYYYMMDD'
    )::INTEGER AS date_key,

    r.review_score,
    r.review_comment_title,
    r.review_comment_message

FROM raw.order_reviews r

JOIN staging.stg_orders o
    ON r.order_id = o.order_id

JOIN dwh.dim_customer dc
    ON o.customer_id = dc.customer_id
    AND dc.is_current = TRUE

WHERE r.review_creation_date IS NOT NULL;