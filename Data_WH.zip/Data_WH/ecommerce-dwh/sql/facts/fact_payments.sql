INSERT INTO dwh.fact_payments (
    order_id,
    customer_sk,
    date_key,
    payment_sequential,
    payment_type,
    payment_installments,
    payment_value
)
SELECT
    p.order_id,

    dc.customer_sk,

    TO_CHAR(
        o.order_purchase_timestamp,
        'YYYYMMDD'
    )::INTEGER AS date_key,

    p.payment_sequential,
    p.payment_type,
    p.payment_installments,
    p.payment_value

FROM raw.order_payments p

JOIN staging.stg_orders o
    ON p.order_id = o.order_id

JOIN dwh.dim_customer dc
    ON o.customer_id = dc.customer_id
    AND dc.is_current = TRUE;