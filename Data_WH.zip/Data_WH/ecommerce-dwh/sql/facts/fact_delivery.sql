INSERT INTO dwh.fact_delivery (
    order_id,
    customer_sk,
    seller_sk,
    date_key,
    delivery_duration_days,
    shipping_duration_days,
    delivery_delay_days
)
SELECT
    o.order_id,

    dc.customer_sk,

    ds.seller_sk,

    TO_CHAR(
        o.order_purchase_timestamp,
        'YYYYMMDD'
    )::INTEGER AS date_key,

    (
        DATE(o.order_delivered_customer_date)
        - DATE(o.order_purchase_timestamp)
    ) AS delivery_duration_days,

    (
        DATE(o.order_delivered_customer_date)
        - DATE(o.order_delivered_carrier_date)
    ) AS shipping_duration_days,

    (
        DATE(o.order_delivered_customer_date)
        - DATE(o.order_estimated_delivery_date)
    ) AS delivery_delay_days

FROM staging.stg_orders o

JOIN dwh.dim_customer dc
    ON o.customer_id = dc.customer_id
    AND dc.is_current = TRUE

JOIN (
    SELECT
        order_id,
        MIN(seller_id) AS seller_id
    FROM staging.stg_order_items
    GROUP BY order_id
) oi
    ON o.order_id = oi.order_id

JOIN dwh.dim_seller ds
    ON oi.seller_id = ds.seller_id
    AND ds.is_current = TRUE

WHERE o.order_delivered_customer_date IS NOT NULL;