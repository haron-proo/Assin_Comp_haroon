INSERT INTO dwh.fact_sales (
    order_id,
    order_item_id,
    customer_sk,
    product_sk,
    seller_sk,
    date_key,
    price,
    freight_value,
    total_amount
)
SELECT
    oi.order_id,
    oi.order_item_id,

    dc.customer_sk,
    dp.product_sk,
    ds.seller_sk,

    TO_CHAR(
        o.order_purchase_timestamp,
        'YYYYMMDD'
    )::INTEGER AS date_key,

    oi.price,
    oi.freight_value,
    (oi.price + oi.freight_value) AS total_amount

FROM staging.stg_order_items oi

JOIN staging.stg_orders o
    ON oi.order_id = o.order_id

JOIN dwh.dim_customer dc
    ON o.customer_id = dc.customer_id
    AND dc.is_current = TRUE

JOIN dwh.dim_product dp
    ON oi.product_id = dp.product_id
    AND dp.is_current = TRUE

JOIN dwh.dim_seller ds
    ON oi.seller_id = ds.seller_id
    AND ds.is_current = TRUE;