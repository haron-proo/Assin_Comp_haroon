SELECT
    d.year,
    d.month,
    COUNT(fs.sales_id) AS total_orders,
    SUM(fs.total_amount) AS total_revenue,
    AVG(fs.total_amount) AS avg_order_value
FROM dwh.fact_sales fs
JOIN dwh.dim_date d
    ON fs.date_key = d.date_key
GROUP BY
    d.year,
    d.month
ORDER BY
    d.year,
    d.month;