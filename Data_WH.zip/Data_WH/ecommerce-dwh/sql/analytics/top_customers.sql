SELECT
    c.customer_id,
    c.customer_city,
    c.customer_state,

    COUNT(fs.sales_id) AS total_orders,
    SUM(fs.total_amount) AS total_spent,
    AVG(fs.total_amount) AS avg_order_value

FROM dwh.fact_sales fs

JOIN dwh.dim_customer c
    ON fs.customer_sk = c.customer_sk

GROUP BY
    c.customer_id,
    c.customer_city,
    c.customer_state

ORDER BY
    total_spent DESC
LIMIT 10;