-- لا يوجد NULL

SELECT COUNT(*) AS null_customer_sk
FROM dwh.fact_sales
WHERE customer_sk IS NULL;

SELECT COUNT(*) AS null_product_sk
FROM dwh.fact_sales
WHERE product_sk IS NULL;


SELECT COUNT(*) AS null_seller_sk
FROM dwh.fact_sales
WHERE seller_sk IS NULL;

SELECT COUNT(*) AS null_date_key
FROM dwh.fact_sales
WHERE date_key IS NULL;



-- *************. Orphan Check

-- هل يوجد Fact بدون Dimension؟


SELECT COUNT(*) AS orphan_customers
FROM dwh.fact_sales fs
LEFT JOIN dwh.dim_customer dc
ON fs.customer_sk = dc.customer_sk
WHERE dc.customer_sk IS NULL;



SELECT COUNT(*) AS orphan_products
FROM dwh.fact_sales fs
LEFT JOIN dwh.dim_product dp
ON fs.product_sk = dp.product_sk
WHERE dp.product_sk IS NULL;


SELECT COUNT(*) AS orphan_sellers
FROM dwh.fact_sales fs
LEFT JOIN dwh.dim_seller ds
ON fs.seller_sk = ds.seller_sk
WHERE ds.seller_sk IS NULL;



-- . Duplicate Grain Check

-- هذا مهم جدًا.

-- هل كسرنا الـ Grain؟

-- المفروض:

-- (order_id + order_item_id) unique

-- نفذ:


SELECT
    order_id,
    order_item_id,
    COUNT(*)
FROM dwh.fact_sales
GROUP BY
    order_id,
    order_item_id
HAVING COUNT(*) > 1;
