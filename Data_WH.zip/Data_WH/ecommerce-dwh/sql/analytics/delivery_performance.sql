SELECT
    ROUND(AVG(delivery_duration_days), 2) AS avg_delivery_days,
    ROUND(AVG(shipping_duration_days), 2) AS avg_shipping_days,
    ROUND(AVG(delivery_delay_days), 2) AS avg_delay_days,

    COUNT(*) AS total_deliveries,

    COUNT(
        CASE
            WHEN delivery_delay_days > 0 THEN 1
        END
    ) AS delayed_orders

FROM dwh.fact_delivery;