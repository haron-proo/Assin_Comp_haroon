CREATE TABLE dwh.dim_customer (
    customer_sk SERIAL PRIMARY KEY,
    customer_id TEXT NOT NULL,
    customer_unique_id TEXT,
    customer_zip_code_prefix INTEGER,
    customer_city TEXT,
    customer_state TEXT,
    effective_date DATE NOT NULL,
    expiry_date DATE,
    is_current BOOLEAN DEFAULT TRUE
);

CREATE TABLE dwh.dim_product (
    product_sk SERIAL PRIMARY KEY,
    product_id TEXT NOT NULL,
    product_category_name TEXT,
    product_name_lenght REAL,
    product_description_lenght REAL,
    product_photos_qty REAL,
    product_weight_g REAL,
    product_length_cm REAL,
    product_height_cm REAL,
    product_width_cm REAL,
    effective_date DATE NOT NULL,
    expiry_date DATE,
    is_current BOOLEAN DEFAULT TRUE
);

CREATE TABLE dwh.dim_seller (
    seller_sk SERIAL PRIMARY KEY,
    seller_id TEXT NOT NULL,
    seller_zip_code_prefix INTEGER,
    seller_city TEXT,
    seller_state TEXT,
    effective_date DATE NOT NULL,
    expiry_date DATE,
    is_current BOOLEAN DEFAULT TRUE
);

CREATE TABLE dwh.dim_date (
    date_key INTEGER PRIMARY KEY,
    full_date DATE NOT NULL,
    year INTEGER,
    quarter INTEGER,
    month INTEGER,
    day INTEGER,
    week INTEGER,
    day_name TEXT,
    month_name TEXT
);

CREATE TABLE dwh.fact_sales (
    sales_id BIGSERIAL PRIMARY KEY,
    order_id TEXT NOT NULL,
    order_item_id INTEGER NOT NULL,

    customer_sk INTEGER NOT NULL,
    product_sk INTEGER NOT NULL,
    seller_sk INTEGER NOT NULL,
    date_key INTEGER NOT NULL,

    price NUMERIC(12,2),
    freight_value NUMERIC(12,2),
    total_amount NUMERIC(12,2),

    FOREIGN KEY (customer_sk)
        REFERENCES dwh.dim_customer(customer_sk),

    FOREIGN KEY (product_sk)
        REFERENCES dwh.dim_product(product_sk),

    FOREIGN KEY (seller_sk)
        REFERENCES dwh.dim_seller(seller_sk),

    FOREIGN KEY (date_key)
        REFERENCES dwh.dim_date(date_key)
);

CREATE TABLE dwh.fact_payments (
    payment_fact_id BIGSERIAL PRIMARY KEY,
    order_id TEXT NOT NULL,

    customer_sk INTEGER NOT NULL,
    date_key INTEGER NOT NULL,

    payment_sequential INTEGER,
    payment_type TEXT,
    payment_installments INTEGER,

    payment_value NUMERIC(12,2),

    FOREIGN KEY (customer_sk)
        REFERENCES dwh.dim_customer(customer_sk),

    FOREIGN KEY (date_key)
        REFERENCES dwh.dim_date(date_key)
);

CREATE TABLE dwh.fact_delivery (
    delivery_fact_id BIGSERIAL PRIMARY KEY,
    order_id TEXT NOT NULL,

    customer_sk INTEGER NOT NULL,
    seller_sk INTEGER NOT NULL,
    date_key INTEGER NOT NULL,

    delivery_duration_days INTEGER,
    shipping_duration_days INTEGER,
    delivery_delay_days INTEGER,

    FOREIGN KEY (customer_sk)
        REFERENCES dwh.dim_customer(customer_sk),

    FOREIGN KEY (seller_sk)
        REFERENCES dwh.dim_seller(seller_sk),

    FOREIGN KEY (date_key)
        REFERENCES dwh.dim_date(date_key)
);

CREATE TABLE dwh.fact_reviews (
    review_fact_id BIGSERIAL PRIMARY KEY,
    review_id TEXT NOT NULL,
    order_id TEXT NOT NULL,

    customer_sk INTEGER NOT NULL,
    date_key INTEGER NOT NULL,

    review_score INTEGER,
    review_comment_title TEXT,
    review_comment_message TEXT,

    FOREIGN KEY (customer_sk)
        REFERENCES dwh.dim_customer(customer_sk),

    FOREIGN KEY (date_key)
        REFERENCES dwh.dim_date(date_key)
);