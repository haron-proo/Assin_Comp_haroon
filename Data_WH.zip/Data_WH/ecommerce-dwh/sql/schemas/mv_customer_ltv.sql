CREATE MATERIALIZED VIEW analytics.mv_customer_ltv AS
SELECT
    c.customer_id,
    c.customer_city,
    c.customer_state,
    COUNT(fs.sales_id) AS total_orders,
    SUM(fs.total_amount) AS lifetime_value
FROM dwh.fact_sales fs
JOIN dwh.dim_customer c
    ON fs.customer_sk = c.customer_sk
GROUP BY
    c.customer_id,
    c.customer_city,
    c.customer_state;