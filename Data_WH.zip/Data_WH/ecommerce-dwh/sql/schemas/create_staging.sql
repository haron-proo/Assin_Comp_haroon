CREATE TABLE staging.stg_customers AS
SELECT DISTINCT
    customer_id,
    customer_unique_id,
    customer_zip_code_prefix,
    TRIM(customer_city) AS customer_city,
    TRIM(customer_state) AS customer_state
FROM raw.customers
WHERE customer_id IS NOT NULL;


CREATE TABLE staging.stg_products AS
SELECT DISTINCT
    product_id,
    product_category_name,
    product_name_lenght,
    product_description_lenght,
    product_photos_qty,
    product_weight_g,
    product_length_cm,
    product_height_cm,
    product_width_cm
FROM raw.products
WHERE product_id IS NOT NULL;


CREATE TABLE staging.stg_sellers AS
SELECT DISTINCT
    seller_id,
    seller_zip_code_prefix,
    TRIM(seller_city) AS seller_city,
    TRIM(seller_state) AS seller_state
FROM raw.sellers
WHERE seller_id IS NOT NULL;


CREATE TABLE staging.stg_orders AS
SELECT DISTINCT
    order_id,
    customer_id,
    order_status,
    order_purchase_timestamp,
    order_approved_at,
    order_delivered_carrier_date,
    order_delivered_customer_date,
    order_estimated_delivery_date
FROM raw.orders
WHERE order_id IS NOT NULL;

CREATE TABLE staging.stg_order_items AS
SELECT DISTINCT
    order_id,
    order_item_id,
    product_id,
    seller_id,
    shipping_limit_date,
    price,
    freight_value
FROM raw.order_items
WHERE order_id IS NOT NULL;