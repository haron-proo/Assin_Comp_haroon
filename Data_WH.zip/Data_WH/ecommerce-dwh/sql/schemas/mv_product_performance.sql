CREATE MATERIALIZED VIEW analytics.mv_product_performance AS
SELECT
    p.product_id,
    p.product_category_name,
    COUNT(fs.sales_id) AS total_sales,
    SUM(fs.total_amount) AS total_revenue
FROM dwh.fact_sales fs
JOIN dwh.dim_product p
    ON fs.product_sk = p.product_sk
GROUP BY
    p.product_id,
    p.product_category_name;