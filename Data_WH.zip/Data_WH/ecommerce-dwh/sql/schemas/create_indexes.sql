-- Dimension Indexes

CREATE INDEX idx_dim_customer_customer_id
ON dwh.dim_customer(customer_id);

CREATE INDEX idx_dim_product_product_id
ON dwh.dim_product(product_id);

CREATE INDEX idx_dim_seller_seller_id
ON dwh.dim_seller(seller_id);

CREATE INDEX idx_dim_date_date_key
ON dwh.dim_date(date_key);

-- Fact Foreign Key Indexes

CREATE INDEX idx_fact_sales_customer_sk
ON dwh.fact_sales(customer_sk);

CREATE INDEX idx_fact_sales_product_sk
ON dwh.fact_sales(product_sk);

CREATE INDEX idx_fact_sales_seller_sk
ON dwh.fact_sales(seller_sk);

CREATE INDEX idx_fact_sales_date_key
ON dwh.fact_sales(date_key);


CREATE INDEX idx_fact_payments_customer_sk
ON dwh.fact_payments(customer_sk);

CREATE INDEX idx_fact_payments_date_key
ON dwh.fact_payments(date_key);

CREATE INDEX idx_fact_delivery_customer_sk
ON dwh.fact_delivery(customer_sk);

CREATE INDEX idx_fact_delivery_seller_sk
ON dwh.fact_delivery(seller_sk);

CREATE INDEX idx_fact_delivery_date_key
ON dwh.fact_delivery(date_key);



CREATE INDEX idx_fact_reviews_customer_sk
ON dwh.fact_reviews(customer_sk);

CREATE INDEX idx_fact_reviews_date_key
ON dwh.fact_reviews(date_key);


-- Index مهم جدًا

-- على order_id داخل Facts:
-- لماذا order_id؟

-- لأننا سنستخدمه في:

-- Cross-Fact Analysis

-- مثال:

-- Sales ↔ Reviews

CREATE INDEX idx_fact_sales_order_id
ON dwh.fact_sales(order_id);

CREATE INDEX idx_fact_payments_order_id
ON dwh.fact_payments(order_id);

CREATE INDEX idx_fact_delivery_order_id
ON dwh.fact_delivery(order_id);

CREATE INDEX idx_fact_reviews_order_id
ON dwh.fact_reviews(order_id);


