let chart;

function clearChart() {
    if (chart) {
        chart.destroy();
    }
}

async function loadTable(url) {
    clearChart();

    const res = await fetch(url);
    const data = await res.json();

    let html = "<table><tr>";

    Object.keys(data[0]).forEach(k => {
        html += "<th>" + k + "</th>";
    });

    html += "</tr>";

    data.forEach(row => {
        html += "<tr>";
        Object.values(row).forEach(v => {
            html += "<td>" + (v ?? "") + "</td>";
        });
        html += "</tr>";
    });

    html += "</table>";

    document.getElementById("output").innerHTML = html;
}

async function loadSales() {
    const res = await fetch("/reports/sales-trends");
    const data = await res.json();

    clearChart();

    const labels = data.map(x => x.month);
    const values = data.map(x => x.total_sales);

    chart = new Chart(document.getElementById("chart"), {
        type: "line",
        data: {
            labels: labels,
            datasets: [{
                label: "Sales",
                data: values,
                borderColor: "#38bdf8"
            }]
        }
    });
}

async function loadDelivery() {
    clearChart();

    const res = await fetch("/reports/delivery-performance");
    const data = await res.json();

    let html = "<table>";

    Object.entries(data).forEach(([k,v]) => {
        html += `<tr><th>${k}</th><td>${v}</td></tr>`;
    });

    html += "</table>";

    document.getElementById("output").innerHTML = html;
}

async function loadReviews() {
    const res = await fetch("/reports/reviews-analysis");
    const data = await res.json();

    clearChart();

    chart = new Chart(document.getElementById("chart"), {
        type: "bar",
        data: {
            labels: data.map(x => x.review_score),
            datasets: [{
                label: "Reviews",
                data: data.map(x => x.total_reviews),
                backgroundColor: "#22c55e"
            }]
        }
    });
}