import sqlite3
from pathlib import Path
from typing import List, Dict, Any


class SQLiteReader:
    """
    Source System Discovery Layer
    Responsible for:
    - Connecting to SQLite source
    - Reading schema metadata
    - Extracting tables info
    - Discovering relationships
    """

    def __init__(self, db_path: str):
        self.db_path = Path(db_path)

        if not self.db_path.exists():
            raise FileNotFoundError(
                f"SQLite database not found: {self.db_path}"
            )

        self.connection = None

    def connect(self):
        self.connection = sqlite3.connect(self.db_path)
        return self.connection

    def close(self):
        if self.connection:
            self.connection.close()

    def get_tables(self) -> List[str]:
        query = """
        SELECT name
        FROM sqlite_master
        WHERE type='table'
        ORDER BY name;
        """

        cursor = self.connection.cursor()
        cursor.execute(query)

        tables = [row[0] for row in cursor.fetchall()]
        return tables

    def get_columns(self, table_name: str) -> List[Dict[str, Any]]:
        query = f"PRAGMA table_info({table_name});"

        cursor = self.connection.cursor()
        cursor.execute(query)

        columns = []

        for row in cursor.fetchall():
            columns.append({
                "column_id": row[0],
                "column_name": row[1],
                "data_type": row[2],
                "not_null": row[3],
                "default_value": row[4],
                "is_primary_key": row[5]
            })

        return columns

    def get_row_count(self, table_name: str) -> int:
        query = f"SELECT COUNT(*) FROM {table_name};"

        cursor = self.connection.cursor()
        cursor.execute(query)

        count = cursor.fetchone()[0]
        return count

    def get_foreign_keys(self, table_name: str):
        query = f"PRAGMA foreign_key_list({table_name});"

        cursor = self.connection.cursor()
        cursor.execute(query)

        foreign_keys = []

        for row in cursor.fetchall():
            foreign_keys.append({
                "table": row[2],
                "from_column": row[3],
                "to_column": row[4]
            })

        return foreign_keys

    def inspect_database(self):
        tables = self.get_tables()

        print("\n==============================")
        print("SOURCE SYSTEM DISCOVERY")
        print("==============================\n")

        for table in tables:
            print(f"\nTABLE: {table}")
            print("-" * 50)

            row_count = self.get_row_count(table)
            print(f"Rows: {row_count}")

            print("\nColumns:")
            columns = self.get_columns(table)

            for col in columns:
                print(
                    f" - {col['column_name']} "
                    f"({col['data_type']}) "
                    f"PK={col['is_primary_key']}"
                )

            foreign_keys = self.get_foreign_keys(table)

            if foreign_keys:
                print("\nForeign Keys:")
                for fk in foreign_keys:
                    print(
                        f" - {fk['from_column']} "
                        f"-> {fk['table']}.{fk['to_column']}"
                    )


def main():
    db_path = "data/source/olist.sqlite"

    reader = SQLiteReader(db_path)

    try:
        reader.connect()
        reader.inspect_database()
    finally:
        reader.close()


if __name__ == "__main__":
    main()