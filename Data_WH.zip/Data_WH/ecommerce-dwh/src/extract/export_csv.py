import sqlite3
import pandas as pd
from pathlib import Path


class SQLiteToCSVExporter:
    """
    Extract data from SQLite
    Export each table to CSV
    """

    def __init__(self, sqlite_path: str, output_dir: str):
        self.sqlite_path = Path(sqlite_path)
        self.output_dir = Path(output_dir)

        if not self.output_dir.exists():
            self.output_dir.mkdir(parents=True, exist_ok=True)

    def connect(self):
        return sqlite3.connect(self.sqlite_path)

    def get_tables(self, connection):
        query = """
        SELECT name
        FROM sqlite_master
        WHERE type='table'
        ORDER BY name;
        """

        cursor = connection.cursor()
        cursor.execute(query)

        return [row[0] for row in cursor.fetchall()]

    def export_all_tables(self):
        connection = self.connect()
        tables = self.get_tables(connection)

        for table in tables:
            print(f"Exporting {table}...")

            query = f"SELECT * FROM {table}"
            df = pd.read_sql_query(query, connection)

            output_file = self.output_dir / f"{table}.csv"

            df.to_csv(
                output_file,
                index=False,
                encoding="utf-8"
            )

            print(f"Saved: {output_file}")

        connection.close()


def main():
    exporter = SQLiteToCSVExporter(
        sqlite_path="data/source/olist.sqlite",
        output_dir="data/raw_csv"
    )

    exporter.export_all_tables()


if __name__ == "__main__":
    main()