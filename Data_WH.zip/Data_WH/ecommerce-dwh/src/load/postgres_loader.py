import psycopg2
from pathlib import Path
from typing import Dict, Set


class PostgresLoader:
    """
    Load selected CSV files into PostgreSQL raw schema.
    Uses whitelist loading to avoid unexpected schema mismatches.
    """

    ALLOWED_TABLES: Set[str] = {
        "customers",
        "orders",
        "order_items",
        "order_payments",
        "order_reviews",
        "products",
        "sellers"
    }

    def __init__(self, db_config: Dict[str, str], data_dir: str):
        self.db_config = db_config
        self.data_dir = Path(data_dir)

        if not self.data_dir.exists():
            raise FileNotFoundError(
                f"Data directory not found: {self.data_dir}"
            )

    def connect(self):
        return psycopg2.connect(
            host=self.db_config["host"],
            port=self.db_config["port"],
            dbname=self.db_config["dbname"],
            user=self.db_config["user"],
            password=self.db_config["password"]
        )

    def load_csv(self, conn, table_name: str, file_path: Path):
        cursor = conn.cursor()

        try:
            with open(file_path, "r", encoding="utf-8") as file:
                next(file)  # Skip CSV header

                cursor.copy_expert(
                    f"""
                    COPY raw.{table_name}
                    FROM STDIN
                    WITH (
                        FORMAT CSV,
                        DELIMITER ',',
                        NULL ''
                    )
                    """,
                    file
                )

            conn.commit()

        except Exception as error:
            conn.rollback()
            raise RuntimeError(
                f"Failed loading {table_name}: {error}"
            )

        finally:
            cursor.close()

    def load_all(self):
        conn = self.connect()

        try:
            for file in self.data_dir.glob("*.csv"):
                table_name = file.stem

                if table_name not in self.ALLOWED_TABLES:
                    print(f"Skipping {table_name}")
                    continue

                print(f"Loading {file.name} into raw.{table_name}...")

                self.load_csv(
                    conn=conn,
                    table_name=table_name,
                    file_path=file
                )

                print(f"Loaded raw.{table_name}")

        finally:
            conn.close()


def main():
    db_config = {
        "host": "localhost",
        "port": 5433,
        "dbname": "ecommerce-dwh-dbs",
        "user": "postgres",
        "password": "123"
    }

    loader = PostgresLoader(
        db_config=db_config,
        data_dir="data/raw_csv"
    )

    loader.load_all()


if __name__ == "__main__":
    main()