from fastapi import FastAPI, Depends
from fastapi.responses import HTMLResponse
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session

# ==========================================
# DATABASE
# ==========================================

DATABASE_URL = "postgresql://postgres:123@localhost:5433/ecommerce-dwh-dbs"

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=3600
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# ==========================================
# APP
# ==========================================

app = FastAPI(title="E-Commerce DWH Dashboard")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ==========================================
# DASHBOARD
# ==========================================

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return """
    <html>
    <head>
        <title>E-Commerce Dashboard</title>

        <style>
            body {
                margin: 0;
                font-family: Arial;
                background: #0f172a;
                color: white;
                display: flex;
            }

            .sidebar {
                width: 220px;
                height: 100vh;
                background: #111827;
                padding: 20px;
            }

            .sidebar h2 {
                color: #38bdf8;
            }

            .btn {
                width: 100%;
                margin: 10px 0;
                padding: 12px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                background: #1e293b;
                color: white;
                transition: 0.3s;
            }

            .btn:hover {
                background: #38bdf8;
                color: black;
            }

            .main {
                flex: 1;
                padding: 20px;
            }

            .header {
                font-size: 24px;
                margin-bottom: 20px;
            }

            .card {
                background: #1e293b;
                padding: 20px;
                border-radius: 12px;
                border: 1px solid #334155;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                font-size: 14px;
            }

            th, td {
                border: 1px solid #334155;
                padding: 8px;
            }

            th {
                background: #334155;
            }
        </style>
    </head>

    <body>

        <div class="sidebar">
            <h2>📊 Dashboard</h2>

            <button class="btn" onclick="load('/reports/sales-trends')">Sales Trends</button>
            <button class="btn" onclick="load('/reports/top-customers')">Top Customers</button>
            <button class="btn" onclick="load('/reports/top-products')">Top Products</button>
            <button class="btn" onclick="load('/reports/delivery-performance')">Delivery</button>
            <button class="btn" onclick="load('/reports/reviews-analysis')">Reviews</button>
        </div>

        <div class="main">
            <div class="header">E-Commerce Analytics Overview</div>

            <div id="output" class="card">
                👈 اختر تقرير من القائمة
            </div>
        </div>

        <script>
            async function load(url) {
                const res = await fetch(url);
                const data = await res.json();

                let html = "<table><tr>";

                if (Array.isArray(data)) {

                    Object.keys(data[0] || {}).forEach(k => {
                        html += "<th>" + k + "</th>";
                    });

                    html += "</tr>";

                    data.forEach(row => {
                        html += "<tr>";
                        Object.values(row).forEach(v => {
                            html += "<td>" + (v ?? "") + "</td>";
                        });
                        html += "</tr>";
                    });

                } else {
                    Object.entries(data).forEach(([k,v]) => {
                        html += "<tr><th>" + k + "</th><td>" + (v ?? "") + "</td></tr>";
                    });
                }

                html += "</table>";

                document.getElementById("output").innerHTML = html;
            }
        </script>

    </body>
    </html>
    """

# ==========================================
# HEALTH
# ==========================================

@app.get("/health")
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok"}

# ==========================================
# REPORTS
# ==========================================

@app.get("/reports/sales-trends")
def sales_trends(db: Session = Depends(get_db)):
    result = db.execute(text("""
        SELECT *
        FROM analytics.mv_monthly_sales
        ORDER BY year, month
    """))
    return [dict(r._mapping) for r in result]


@app.get("/reports/top-customers")
def top_customers(db: Session = Depends(get_db)):
    result = db.execute(text("""
        SELECT *
        FROM analytics.mv_customer_ltv
        LIMIT 10
    """))
    return [dict(r._mapping) for r in result]


@app.get("/reports/top-products")
def top_products(db: Session = Depends(get_db)):
    result = db.execute(text("""
        SELECT *
        FROM analytics.mv_product_performance
        LIMIT 10
    """))
    return [dict(r._mapping) for r in result]


@app.get("/reports/delivery-performance")
def delivery(db: Session = Depends(get_db)):
    result = db.execute(text("""
        SELECT
            AVG(delivery_days) AS avg_delivery_days,
            AVG(shipping_days) AS avg_shipping_days,
            AVG(delay_days) AS avg_delay_days,
            COUNT(*) AS total_deliveries
        FROM mart.fact_sales
    """)).fetchone()

    return dict(result._mapping)


@app.get("/reports/reviews-analysis")
def reviews(db: Session = Depends(get_db)):
    result = db.execute(text("""
        SELECT
            review_score,
            COUNT(*) AS total_reviews
        FROM mart.fact_sales
        GROUP BY review_score
        ORDER BY review_score DESC
    """))
    return [dict(r._mapping) for r in result]