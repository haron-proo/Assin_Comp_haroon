from pathlib import Path


PROJECT_NAME = "ecommerce-dwh"

PROJECT_STRUCTURE = {
    "config": [
        "config.py",
        "db_config.py",
        "settings.py"
    ],

    "data": {
        "source": [
            "olist.sqlite"
        ],
        "raw_csv": [],
        "logs": []
    },

    "sql": {
        "schemas": [
            "create_raw.sql",
            "create_staging.sql",
            "create_dwh.sql"
        ],

        "dimensions": [
            "dim_customer.sql",
            "dim_product.sql",
            "dim_seller.sql",
            "dim_date.sql"
        ],

        "facts": [
            "fact_sales.sql",
            "fact_payments.sql",
            "fact_delivery.sql",
            "fact_reviews.sql"
        ],

        "analytics": [
            "sales_trends.sql",
            "top_customers.sql",
            "delivery_performance.sql"
        ]
    },

    "src": {
        "extract": [
            "sqlite_reader.py",
            "export_csv.py"
        ],

        "load": [
            "postgres_loader.py",
            "bulk_loader.py"
        ],

        "transform": [
            "clean_orders.py",
            "transform_dimensions.py",
            "transform_facts.py",
            "scd_handler.py"
        ],

        "pipeline": [
            "etl_pipeline.py",
            "orchestration.py"
        ],

        "utils": [
            "logger.py",
            "validator.py",
            "helpers.py"
        ]
    },

    "docs": [
        "architecture.md",
        "business_process.md",
        "star_schema.md",
        "grain_definition.md",
        "decisions.md"
    ],

    "tests": [],

    "root_files": [
        "requirements.txt",
        ".env",
        "main.py"
    ]
}


def create_file(file_path: Path):
    file_path.parent.mkdir(parents=True, exist_ok=True)

    if not file_path.exists():
        file_path.touch()
        print(f"[FILE CREATED] {file_path}")
    else:
        print(f"[EXISTS] {file_path}")


def create_structure(base_path: Path, structure):
    for name, content in structure.items():

        if name == "root_files":
            for file_name in content:
                create_file(base_path / file_name)

        elif isinstance(content, list):
            folder_path = base_path / name
            folder_path.mkdir(parents=True, exist_ok=True)

            print(f"[DIR CREATED] {folder_path}")

            for file_name in content:
                create_file(folder_path / file_name)

        elif isinstance(content, dict):
            folder_path = base_path / name
            folder_path.mkdir(parents=True, exist_ok=True)

            print(f"[DIR CREATED] {folder_path}")

            create_structure(folder_path, content)


def main():
    root = Path(PROJECT_NAME)

    root.mkdir(parents=True, exist_ok=True)

    print(f"\nCreating project: {PROJECT_NAME}\n")

    create_structure(root, PROJECT_STRUCTURE)

    print("\nProject structure created successfully.")


if __name__ == "__main__":
    main()