#!/bin/bash

set -e

# تحديد مكان السكربت
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# البحث عن أي ملف .deb داخل المجلد
DEB_FILE=$(find "$SCRIPT_DIR" -maxdepth 1 -name "*.deb" | head -n 1)

TMP_DEB="/tmp/drharoon.deb"
APP_DIR="/opt/drharoon"

echo "==> Looking for .deb file..."

if [ -z "$DEB_FILE" ]; then
    echo "ERROR: No .deb file found in script folder!"
    exit 1
fi

echo "==> Using DEB file: $DEB_FILE"

echo "==> Fixing permissions..."
chmod 644 "$DEB_FILE"

echo "==> Copying to /tmp..."
sudo cp "$DEB_FILE" "$TMP_DEB"

echo "==> Installing package..."
sudo apt update -y
sudo apt install -y "$TMP_DEB"

echo "==> Checking installation..."
if [ ! -d "$APP_DIR" ]; then
    echo "ERROR: $APP_DIR not found!"
    exit 1
fi

echo "==> Checking virtual environment..."
if [ ! -f "$APP_DIR/venv/bin/activate" ]; then
    echo "ERROR: venv not found!"
    exit 1
fi

echo "==> Starting app..."
cd "$APP_DIR"
source venv/bin/activate

# إيقاف أي تشغيل سابق
pkill -f uvicorn || true

# تشغيل التطبيق
nohup uvicorn main:app --host 0.0.0.0 --port 8012 > app.log 2>&1 &

sleep 2

echo "==> Done!"
IP=$(hostname -I | awk '{print $1}')
echo "App running at: http://$IP:8012"
echo "Logs: $APP_DIR/app.log"
