import pandas as pd
import numpy as np

df = pd.read_csv("employees_dirty_100.csv")

df = df.drop_duplicates()

df = df.dropna(subset=["FullName"])

df["Age"] = pd.to_numeric(df["Age"], errors="coerce")
df["Age"] = df["Age"].fillna(df["Age"].mean())

df["Salary"] = df["Salary"].astype(str).str.strip()
df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")
df["Salary"] = df["Salary"].fillna(df["Salary"].mean())

df["JoinDate"] = pd.to_datetime(df["JoinDate"], errors="coerce")
df = df.dropna(subset=["JoinDate"])

df = df[df["Email"].str.contains("@", na=False)]

df["Department"] = df["Department"].str.strip().str.title()
df["FullName"] = df["FullName"].str.strip()

df = df.reset_index(drop=True)

df.to_csv("employees_cleaned.csv", index=False)