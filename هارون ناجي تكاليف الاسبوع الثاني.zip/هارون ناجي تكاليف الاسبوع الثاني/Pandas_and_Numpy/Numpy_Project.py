from tkinter.font import names
import numpy as np

data = np.genfromtxt(
    'articls.csv',
    delimiter=',',
    names=True,
    dtype=None,
    encoding='utf-8'
)
name = data['name']

articles = data['article']

print('*'*50)
print("Number of articles:", len(articles))
print('*'*50)

import re

def tokenize(text):
    text = text.lower()
    words = re.findall(r'\b\w+\b', text)
    return words

tokenized_articles = [tokenize(article) for article in articles]

print("frist article", tokenized_articles[0])
print('*'*50)

all_words = set(word for article in tokenized_articles for word in article)

word_to_index = {word: idx for idx, word in enumerate(sorted(all_words))}

print("Numbers of unique words:", len(all_words))
print('*'*50)

num_articles = len(tokenized_articles)
num_words = len(word_to_index)

bow_matrix = np.zeros((num_articles, num_words), dtype=int)
for i, article in enumerate(tokenized_articles):
    for word in article:
        idx = word_to_index[word]
        bow_matrix[i, idx] += 1

print("  Bag of Words:", bow_matrix.shape)
print('*'*50)

def cosine_similarity(matrix):
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)

    similarity_matrix = np.dot(matrix, matrix.T) / (norms @ norms.T)
    similarity_matrix = np.nan_to_num(similarity_matrix)
    return similarity_matrix

sim_matrix = cosine_similarity(bow_matrix)
print("Cosine Similarity Matrix:\n", sim_matrix)
print('*'*50)

def compare_articles_interactive():
    print("Enter the First Article (1-15):")
    idx1 = int(input()) - 1
    print("Enter the second Article (1-15):")
    idx2 = int(input()) - 1
    if idx1 < 0 or idx1 >= num_articles or idx2 < 0 or idx2 >= num_articles:
        print("Error: number is out of  (1-15)")
        return
    name1, name2 = name[idx1], name[idx2]
    article1, article2 = articles[idx1], articles[idx2]
    similarity = sim_matrix[idx1, idx2]
    print("\n" + "=" * 50)
    print(f"first article  ({idx1 + 1}): {name1}\n{article1}\n")
    print(f"second article  ({idx2 + 1}): {name2}\n{article2}\n")
    print(f" the similatiry: {similarity:.2f}")
    print("=" * 50 + "\n")
compare_articles_interactive()