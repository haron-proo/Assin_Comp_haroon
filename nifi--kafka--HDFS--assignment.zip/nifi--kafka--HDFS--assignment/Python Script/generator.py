import csv
import random
import time
import uuid
from datetime import datetime
from pathlib import Path

output_folder = Path(
    r"E:\Data Engineering Bootcamp Lab\spark-sql-and-pyspark-using-python3\lab_data"
)

output_folder.mkdir(exist_ok=True)

products = [
    "Laptop",
    "Smartphone",
    "Headphones",
    "Monitor",
    "Keyboard"
]

customers = []

for i in range(1, 20):
    customers.append(f"CUST{i:03}")


def generate_record():

    transaction_id = str(uuid.uuid4())[:8]

    customer_id = random.choice(customers)

    product_name = random.choice(products)

    amount = round(random.uniform(10, 1500), 2)

    current_date = datetime.now()

    # أحيانا يغير صيغة الوقت
    if random.random() < 0.2:
        timestamp = current_date.strftime("%d/%m/%Y %H:%M:%S")
    else:
        timestamp = current_date.strftime("%Y-%m-%d %H:%M:%S")

    # أحيانا يجعل العميل فارغ
    if random.random() < 0.1:
        customer_id = ""

    # أحيانا يجعل السعر سالب
    if random.random() < 0.1:
        amount = amount * -1

    # أحيانا يولد صف تالف
    if random.random() < 0.05:
        return [
            "CORRUPTED_ROW_ERROR",
            "###",
            "NULL",
            "???"
        ]

    row = [
        transaction_id,
        customer_id,
        product_name,
        amount,
        timestamp
    ]

    return row


def start_generator():

    print("Starting stream...")
    print(f"Output directory: {output_folder}")

    counter = 1

    while True:

        timestamp_now = int(time.time())

        file_name = (
            f"ecommerce_batch_{counter}_{timestamp_now}.csv"
        )

        file_path = output_folder / file_name

        number_of_records = random.randint(50, 200)

        rows = []

        for _ in range(number_of_records):

            record = generate_record()

            rows.append(record)

        # أحيانا يضيف تكرار
        if len(rows) > 0:

            if random.random() < 0.15:
                rows.append(rows[0])

        with open(file_path, "w", newline="") as file:

            writer = csv.writer(file)

            header = [
                "transaction_id",
                "customer_id",
                "product",
                "amount",
                "timestamp"
            ]

            writer.writerow(header)

            for row in rows:
                writer.writerow(row)

        print(
            f"{file_name} created successfully "
            f"with {len(rows)} rows"
        )

        counter += 1

        wait_time = random.randint(3, 7)

        time.sleep(wait_time)


if __name__ == "__main__":
    start_generator()